import json
import os
import uuid
from datetime import datetime, timezone
from pathlib import Path

import httpx
from anthropic import (
    Anthropic,
    APIConnectionError,
    APIStatusError,
    AuthenticationError,
    RateLimitError,
)
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

load_dotenv()

ANTHROPIC_API_KEY = os.getenv("ANTHROPIC_API_KEY")
MODEL = "claude-sonnet-4-6"
REDDIT_UA = "kveeloo-scraper/1.0 (by /u/local-tool)"

BASE_DIR = Path(__file__).parent
INDEX_PATH = BASE_DIR / "reddit_story_scraper.html"
HISTORY_PATH = BASE_DIR / "history.jsonl"

app = FastAPI(title="Reddit → Kveeloo Prompt Builder")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


class FetchRequest(BaseModel):
    subreddits: list[str]
    sort: str = Field(default="top", pattern="^(hot|top|new|rising)$")
    time_range: str = Field(default="day", pattern="^(day|week|month|year|all)$")
    min_score: int = 0
    limit_per_sub: int = 10


class Story(BaseModel):
    id: str
    sub: str
    title: str
    score: int = 0
    text: str = ""
    url: str = ""
    author: str = ""
    comments: int = 0


class GenerateRequest(BaseModel):
    stories: list[Story]


KVEELOO_SYSTEM = """You write short-form video prompts for Kveeloo (a faceless-video tool).

Given one or more Reddit posts, distill the most interesting fact, story, or insight and output ONE prompt in EXACTLY this format — no preamble, no commentary, no markdown headers, just the labeled fields below, in this order, separated by blank lines:

Topic: <one sentence stating what the video is about>

Hook: <one attention-grabbing opening line, ideally a question or a "did you know" framing>

Format: <short description of the video format, e.g. "Did-you-know / fact reveal — short, punchy, conversational" or "Story recap — first-person, dramatic">

Key points to cover:
1. <first key point>
2. <second key point>
3. <third key point>
4. <fourth key point — optional if the story is thin>

Tone: <2–4 adjectives describing voice/energy>
Length: <duration range, e.g. "35–45 seconds">
End with: "<the literal closing line the narrator should say>"

Rules:
- Output ONLY the fields above, in that exact order, with those exact labels.
- The "End with" line must be wrapped in double quotes.
- Keep each line tight. No fluff, no setup, no "Here is your prompt:" intro.
- If multiple Reddit posts are provided, synthesize a single unifying topic rather than listing them separately.
"""


def _build_user_prompt(stories: list[Story]) -> str:
    blocks = []
    for i, s in enumerate(stories, 1):
        blocks.append(
            f"--- Post {i} (r/{s.sub}) ---\n"
            f"Title: {s.title}\n"
            f"Score: {s.score} · Comments: {s.comments}\n"
            f"URL: {s.url}\n\n"
            f"{s.text}"
        )
    joined = "\n\n".join(blocks)
    return (
        "Here are the Reddit post(s) to turn into a Kveeloo prompt:\n\n"
        f"{joined}\n\n"
        "Now produce the prompt in the exact format specified."
    )


@app.get("/")
def index():
    if not INDEX_PATH.exists():
        raise HTTPException(404, f"missing {INDEX_PATH.name}")
    return FileResponse(INDEX_PATH)


@app.get("/healthz")
def healthz():
    return {"ok": True, "has_key": bool(ANTHROPIC_API_KEY), "model": MODEL}


@app.post("/api/fetch")
async def fetch_stories(req: FetchRequest):
    if not req.subreddits:
        raise HTTPException(400, "no subreddits provided")

    results: list[dict] = []

    async with httpx.AsyncClient(
        headers={"User-Agent": REDDIT_UA},
        timeout=20.0,
        follow_redirects=True,
    ) as client:
        for sub in req.subreddits:
            sub_clean = sub.strip().lstrip("r/").strip("/")
            if not sub_clean:
                continue
            url = (
                f"https://www.reddit.com/r/{sub_clean}/{req.sort}.json"
                f"?limit=50&t={req.time_range}"
            )
            try:
                r = await client.get(url)
                r.raise_for_status()
                data = r.json()
            except Exception as e:
                print(f"[fetch] {sub_clean} failed: {e}")
                continue

            posts = []
            for child in data.get("data", {}).get("children", []):
                p = child.get("data", {})
                if p.get("stickied"):
                    continue
                if p.get("score", 0) < req.min_score:
                    continue
                selftext = p.get("selftext") or ""
                if len(selftext) < 100:
                    continue
                posts.append({
                    "id": p.get("id", ""),
                    "sub": sub_clean,
                    "title": p.get("title", ""),
                    "score": p.get("score", 0),
                    "text": selftext[:2000],
                    "url": f"https://reddit.com{p.get('permalink', '')}",
                    "author": p.get("author", ""),
                    "comments": p.get("num_comments", 0),
                })

            posts.sort(key=lambda x: x["score"], reverse=True)
            results.extend(posts[: req.limit_per_sub])

    return {"stories": results, "count": len(results)}


def _append_history(entry: dict) -> None:
    with HISTORY_PATH.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry, ensure_ascii=False) + "\n")


def _read_history() -> list[dict]:
    if not HISTORY_PATH.exists():
        return []
    out: list[dict] = []
    with HISTORY_PATH.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except json.JSONDecodeError:
                continue
    return out


@app.post("/api/generate")
def generate_prompt(req: GenerateRequest):
    if not ANTHROPIC_API_KEY:
        raise HTTPException(500, "ANTHROPIC_API_KEY is not set on the server")
    if not req.stories:
        raise HTTPException(400, "no stories provided")

    client = Anthropic(api_key=ANTHROPIC_API_KEY)
    try:
        msg = client.messages.create(
            model=MODEL,
            max_tokens=1024,
            system=KVEELOO_SYSTEM,
            messages=[{"role": "user", "content": _build_user_prompt(req.stories)}],
        )
    except AuthenticationError:
        raise HTTPException(
            401,
            "Anthropic rejected the API key. Check ANTHROPIC_API_KEY in .env "
            "(must be a real key from console.anthropic.com, not the placeholder).",
        )
    except RateLimitError:
        raise HTTPException(429, "Anthropic rate limit hit — try again in a moment.")
    except APIConnectionError as e:
        raise HTTPException(502, f"Could not reach Anthropic: {e}")
    except APIStatusError as e:
        raise HTTPException(502, f"Anthropic API error {e.status_code}: {e.message}")

    text = "".join(b.text for b in msg.content if b.type == "text").strip()

    entry = {
        "id": uuid.uuid4().hex[:12],
        "created_at": datetime.now(timezone.utc).isoformat(),
        "model": MODEL,
        "stories": [s.model_dump() for s in req.stories],
        "prompt": text,
    }
    _append_history(entry)
    return {"id": entry["id"], "prompt": text, "created_at": entry["created_at"]}


@app.get("/api/history")
def list_history(limit: int = 50):
    entries = _read_history()
    entries.reverse()
    return {"entries": entries[:limit], "total": len(entries)}


@app.get("/api/history/{entry_id}")
def get_history_entry(entry_id: str):
    for e in _read_history():
        if e.get("id") == entry_id:
            return e
    raise HTTPException(404, "not found")


if __name__ == "__main__":
    import uvicorn

    uvicorn.run("server:app", host="0.0.0.0", port=8000, reload=True)
