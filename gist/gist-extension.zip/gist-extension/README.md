# ✦ Gist — highlight to summarize

The real, working version of the browser extension from **Build With AI, Episode 9**.
Highlight any text on any page → a floating card gives you the gist, powered by Claude:

- **Summarize** — the core point, faithfully
- **Explain** — the same text in plain language
- **Rewrite** — a clearer, tighter version

Every mode answers in **TL;DR style** — one punchy `TL;DR:` line plus a few tight bullets, so it's scannable at a glance.

It's a Manifest V3 Chrome extension: a content script draws the UI, a background service
worker makes the Claude call, and a popup holds your settings. No build step, no server.
The response **streams in live** (text appears as it generates), and closing the card
cancels the request so you don't pay for tokens you won't read.

---

## Load it (unpacked, ~1 minute)

> New to unpacked extensions? See **[INSTALL.md](INSTALL.md)** for a full click-by-click
> walkthrough with screenshots-worth of detail and troubleshooting. The short version:

1. Open **`chrome://extensions`** in Chrome (or Edge/Brave/Arc — any Chromium browser).
2. Turn on **Developer mode** (top-right).
3. Click **Load unpacked** and pick this folder:
   `AI_BlogSite/Apps/gist-extension/`
4. The **✦ Gist** icon appears in your toolbar.

## Add your API key (one time)

Gist runs on **your own** Anthropic API key — it's never hardcoded, and it only ever
goes to `api.anthropic.com`.

1. Get a key at **[console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)**.
2. Click the **✦ Gist** toolbar icon.
3. Paste the key, pick a model (Haiku 4.5 is the fast default), and hit **Save**.

## Use it

Select text on any page → click the little **✦ Gist** pill that appears → read the gist.
Switch between **Summarize / Explain / Rewrite** with the tabs. Press the tabs again to re-run.

**Keyboard shortcut:** highlight text and press **⌘⇧G** (macOS) / **Ctrl+Shift+G** (Windows/Linux)
to gist it instantly — no pill. If that combo is taken on your machine, the extension still
loads; set your own key at **`chrome://extensions/shortcuts`** (the popup shows the current
binding and has a **Change** button).

In the card you can also:

- **Drag it** by the header (⠿) to move it off whatever you're reading
- **⧉ Copy** the result to your clipboard (one click)
- **↻ Retry** for a fresh take on the same mode
- **Ask a follow-up** — type a question about the selection in the box at the bottom and hit Enter
  (e.g. "what does this mean?", "is this accurate?"); your question shows above the answer
- **Esc** to close the card. The card also **remembers your last mode** (kept in sync with the popup).

---

## Files

| File | Job |
|---|---|
| `manifest.json` | MV3 config — permissions (`storage`), host access to `api.anthropic.com`, wiring |
| `content.js` | Detects selections, draws the trigger + card in an isolated **shadow DOM**, renders the streaming text over a port |
| `background.js` | Service worker — the only thing that calls Claude; streams the SSE response chunk-by-chunk and aborts the fetch if you close the card |
| `popup.html` / `popup.js` | Settings: API key, model, default mode → `chrome.storage.local` |
| `icons/` | Toolbar icons (16 / 48 / 128) |

## Notes & honest caveats

- **Your key stays local.** It lives in `chrome.storage.local` on your machine and is sent
  only to Anthropic. Don't paste an API key into random sites — only into this popup.
- **Cost is yours.** Every gist is one Claude API call billed to your key. Haiku 4.5 keeps
  it cheap; switch models in the popup if you want deeper output.
- **Model IDs** default to `claude-haiku-4-5-20251001`; Sonnet 5 / Opus 4.8 are options.
- **Not published.** This is meant to run unpacked, just for you. Publishing to the Chrome
  Web Store is a separate (reviewed) step and isn't required to use it.

Built with Claude, zero code — by [AIToolsDaily24](https://aitoolsdaily24.com). Part of *The Stack*.
