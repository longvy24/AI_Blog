// Gist — content script.
// Watches for a text selection on any page, shows a small "✦ Gist" trigger, and on
// click (or the ⌘⇧G shortcut) opens a floating card that streams a Claude response from
// the background worker over a long-lived port. Supports Summarize / Explain / Rewrite,
// a custom follow-up "Ask", copy, retry, and Esc-to-close. All UI lives in a shadow root
// so page styles can't bleed in (and ours can't leak out).

(() => {
  if (window.__gistInjected) return;
  window.__gistInjected = true;

  const ACCENT = "#EF4444";
  const MODES = ["summarize", "explain", "rewrite"];
  const LABELS = { summarize: "Summarize", explain: "Explain", rewrite: "Rewrite", ask: "Thinking" };

  // ---- shadow host ----
  const host = document.createElement("div");
  host.id = "gist-host";
  host.style.cssText = "position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;";
  const shadow = host.attachShadow({ mode: "open" });
  (document.documentElement || document.body).appendChild(host);

  const style = document.createElement("style");
  style.textContent = `
    * { box-sizing:border-box; margin:0; padding:0;
        font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,Helvetica,Arial,sans-serif; }
    .trigger { position:fixed; display:none; align-items:center; gap:6px; background:#1A1313;
        color:${ACCENT}; border:1px solid ${ACCENT}; border-radius:999px; padding:7px 13px;
        font-size:13px; font-weight:600; letter-spacing:.3px; cursor:pointer; user-select:none;
        box-shadow:0 6px 20px rgba(0,0,0,.4),0 0 14px rgba(239,68,68,.25); }
    .trigger:hover { background:${ACCENT}; color:#fff; }
    .card { position:fixed; display:none; width:360px; max-width:calc(100vw - 24px); background:#17110F;
        color:#F2E9E7; border:1px solid ${ACCENT}; border-radius:14px; overflow:hidden;
        box-shadow:0 20px 60px rgba(0,0,0,.55),0 0 30px rgba(239,68,68,.18); }
    .head { display:flex; align-items:center; gap:8px; padding:12px 14px; border-bottom:1px solid #332323; background:#201615; cursor:move; user-select:none; }
    .head:active { cursor:grabbing; }
    .grip { color:#5A4A4A; font-size:14px; line-height:1; letter-spacing:-2px; margin-right:2px; }
    .logo { font-size:16px; font-weight:800; color:${ACCENT}; letter-spacing:.3px; }
    .by { font-size:11px; color:#A08A88; }
    .x { margin-left:auto; cursor:pointer; color:#A08A88; font-size:19px; line-height:1; padding:0 4px; }
    .x:hover { color:#fff; }
    .tabs { display:flex; gap:6px; padding:11px 14px 0; }
    .tab { font-size:12px; color:#A08A88; padding:6px 12px; border:1px solid #332323; border-radius:8px; cursor:pointer; user-select:none; }
    .tab.on { color:${ACCENT}; border-color:${ACCENT}; background:rgba(239,68,68,.10); font-weight:600; }
    .body { padding:14px; font-size:14px; line-height:1.5; min-height:52px; max-height:280px; overflow-y:auto; word-wrap:break-word; }
    .body div { margin:2px 0; }
    .tldr { color:${ACCENT}; font-weight:700; }
    .body ul { margin:8px 0 0; padding-left:18px; }
    .body li { margin:3px 0; }
    .qask { color:#A08A88; font-style:italic; border-left:2px solid ${ACCENT}; padding-left:8px; margin-bottom:8px; }
    .muted { color:#A08A88; }
    .err { color:#F89; }
    .spin { display:inline-block; width:14px; height:14px; border:2px solid #332323; border-top-color:${ACCENT};
        border-radius:50%; animation:gs .7s linear infinite; vertical-align:-2px; margin-right:8px; }
    @keyframes gs { to { transform:rotate(360deg); } }
    .caret { display:inline-block; width:2px; height:1.05em; margin-left:2px; background:${ACCENT};
        vertical-align:-2px; animation:gblink 1.05s step-end infinite; }
    @keyframes gblink { 50% { opacity:0; } }
    .actions { display:none; gap:8px; padding:2px 14px 10px; }
    .actions.show { display:flex; }
    .act { display:inline-flex; align-items:center; gap:6px; background:transparent; border:1px solid #332323;
        color:#A08A88; border-radius:8px; padding:6px 11px; font-size:12px; cursor:pointer; }
    .act:hover { border-color:${ACCENT}; color:#F2E9E7; }
    .ask { display:flex; gap:8px; padding:10px 14px 12px; border-top:1px solid #332323; }
    .ask-in { flex:1; background:#221818; border:1px solid #332323; border-radius:8px; color:#F2E9E7; padding:8px 12px; font-size:13px; }
    .ask-in:focus { outline:none; border-color:${ACCENT}; }
    .ask-in::placeholder { color:#6E5757; }
    .ask-send { background:${ACCENT}; color:#fff; border:none; border-radius:8px; padding:0 14px; font-size:15px; cursor:pointer; }
    .ask-send:hover { background:#DC2626; }
    .toast { position:fixed; left:50%; bottom:28px; transform:translateX(-50%) translateY(8px); display:none;
        opacity:0; background:#1A1313; color:#F2E9E7; border:1px solid ${ACCENT}; border-radius:999px;
        padding:10px 18px; font-size:13px; white-space:nowrap; box-shadow:0 8px 24px rgba(0,0,0,.5);
        transition:opacity .22s ease, transform .22s ease; }
    .toast.show { opacity:1; transform:translateX(-50%) translateY(0); }
  `;
  shadow.appendChild(style);

  const trigger = document.createElement("div");
  trigger.className = "trigger";
  trigger.innerHTML = "<span>✦</span><span>Gist</span>";
  shadow.appendChild(trigger);

  const card = document.createElement("div");
  card.className = "card";
  card.innerHTML =
    '<div class="head"><span class="grip">⠿</span><span class="logo">✦ Gist</span><span class="by">powered by Claude</span><span class="x" data-x>×</span></div>' +
    '<div class="tabs"></div>' +
    '<div class="body"></div>' +
    '<div class="actions"><button class="act" data-copy>⧉ Copy</button><button class="act" data-regen>↻ Retry</button></div>' +
    '<div class="ask"><input class="ask-in" type="text" placeholder="Ask a follow-up…"><button class="ask-send" data-ask title="Ask">↵</button></div>';
  shadow.appendChild(card);

  const toast = document.createElement("div");
  toast.className = "toast";
  shadow.appendChild(toast);

  const tabsEl = card.querySelector(".tabs");
  const bodyEl = card.querySelector(".body");
  const actionsEl = card.querySelector(".actions");
  const copyBtn = card.querySelector("[data-copy]");
  const askInput = card.querySelector(".ask-in");
  MODES.forEach((m) => {
    const t = document.createElement("span");
    t.className = "tab";
    t.dataset.mode = m;
    t.textContent = LABELS[m];
    tabsEl.appendChild(t);
  });

  let selectedText = "";
  let anchor = { left: 0, right: 0, top: 0, bottom: 0 };
  let currentMode = "summarize";
  let currentQuestion = null;
  let prelude = "";
  let lastText = "";
  let currentRun = null;
  let toastTimer = null, toastHide = null, copyTimer = null;
  let dragging = false, dragDX = 0, dragDY = 0, cardMoved = false;

  const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
  const fmt = (s) => esc(s).replace(/\*\*(.+?)\*\*/g, "<b>$1</b>");

  function showToast(text) {
    toast.textContent = text;
    toast.style.display = "block";
    clearTimeout(toastHide);
    requestAnimationFrame(() => toast.classList.add("show"));
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => {
      toast.classList.remove("show");
      toastHide = setTimeout(() => { toast.style.display = "none"; }, 260);
    }, 1600);
  }

  function fallbackCopy(t) {
    try {
      const ta = document.createElement("textarea");
      ta.value = t;
      ta.style.cssText = "position:fixed;left:-9999px;opacity:0;";
      document.body.appendChild(ta);
      ta.select();
      const ok = document.execCommand("copy");
      document.body.removeChild(ta);
      return ok;
    } catch (_) { return false; }
  }
  function copyText(t) {
    if (navigator.clipboard && navigator.clipboard.writeText) {
      return navigator.clipboard.writeText(t).then(() => true).catch(() => fallbackCopy(t));
    }
    return Promise.resolve(fallbackCopy(t));
  }

  function captureSelection() {
    const sel = window.getSelection();
    const text = sel ? sel.toString().trim() : "";
    if (!text || text.length < 2 || !sel.rangeCount) return false;
    const rect = sel.getRangeAt(0).getBoundingClientRect();
    if (!rect || (rect.width === 0 && rect.height === 0)) return false;
    selectedText = text;
    anchor = { left: rect.left, right: rect.right, top: rect.top, bottom: rect.bottom };
    return true;
  }

  function renderResult(text, streaming) {
    const lines = text.split(/\n+/).map((l) => l.trim()).filter(Boolean);
    let html = "", inList = false;
    for (const line of lines) {
      const bullet = line.match(/^[-*•]\s+(.*)/);
      if (bullet) {
        if (!inList) { html += "<ul>"; inList = true; }
        html += `<li>${fmt(bullet[1])}</li>`;
        continue;
      }
      if (inList) { html += "</ul>"; inList = false; }
      const tldr = line.match(/^(TL;DR:?)(.*)/i);
      if (tldr) html += `<div><span class="tldr">${esc(tldr[1])}</span>${fmt(tldr[2])}</div>`;
      else html += `<div>${fmt(line)}</div>`;
    }
    if (inList) html += "</ul>";
    const caret = streaming ? '<span class="caret"></span>' : "";
    const inner = html ? html + caret : (streaming ? caret : '<span class="muted">(empty)</span>');
    bodyEl.innerHTML = prelude + inner;
  }

  function placeCard() {
    if (cardMoved) { card.style.display = "block"; return; } // keep where the user dragged it
    card.style.visibility = "hidden";
    card.style.display = "block";
    const w = card.offsetWidth, h = card.offsetHeight;
    let x = anchor.left + (anchor.right - anchor.left) / 2 - w / 2;
    x = Math.min(Math.max(8, x), window.innerWidth - w - 8);
    let y = anchor.bottom + 10;
    if (y + h > window.innerHeight - 8) y = Math.max(8, anchor.top - h - 12);
    card.style.left = x + "px";
    card.style.top = y + "px";
    card.style.visibility = "visible";
  }

  function setActiveTab() {
    tabsEl.querySelectorAll(".tab").forEach((t) => t.classList.toggle("on", t.dataset.mode === currentMode));
  }

  // True while our extension context is valid. After the extension is reloaded/updated,
  // a content script already injected into an open tab is "orphaned" — any chrome.* call
  // throws "Extension context invalidated". We detect that and ask the user to refresh.
  const alive = () => { try { return !!(chrome.runtime && chrome.runtime.id); } catch (_) { return false; } };

  function showRefresh() {
    prelude = "";
    actionsEl.classList.remove("show");
    bodyEl.innerHTML = '<span class="muted">Gist was updated. <b>Refresh this page</b> (⌘R / Ctrl+R) to use it here.</span>';
    placeCard();
  }

  function run() {
    setActiveTab();
    if (!alive()) { showRefresh(); return; }
    if (currentRun) currentRun.cancel();
    actionsEl.classList.remove("show");
    copyBtn.textContent = "⧉ Copy";
    prelude = currentMode === "ask" && currentQuestion ? `<div class="qask">${esc(currentQuestion)}</div>` : "";
    bodyEl.innerHTML = prelude + `<span class="muted"><span class="spin"></span>${LABELS[currentMode]}…</span>`;
    placeCard();

    let port;
    try {
      port = chrome.runtime.connect({ name: "gist" });
    } catch (_) {
      showRefresh();
      return;
    }

    let acc = "", started = false, finished = false, cancelled = false;
    const thisRun = { cancel() { cancelled = true; try { port.disconnect(); } catch (_) {} } };
    currentRun = thisRun;

    port.onMessage.addListener((msg) => {
      if (cancelled || !msg) return;
      if (msg.type === "chunk") {
        started = true;
        acc += msg.text;
        renderResult(acc, true);
        bodyEl.scrollTop = bodyEl.scrollHeight;
      } else if (msg.type === "done") {
        finished = true;
        lastText = acc;
        renderResult(acc, false);
        if (acc.trim()) actionsEl.classList.add("show");
        placeCard();
        try { port.disconnect(); } catch (_) {}
      } else if (msg.type === "error") {
        finished = true;
        if (msg.error === "NO_KEY") {
          bodyEl.innerHTML =
            '<span class="muted">Add your <b>Anthropic API key</b> to start.<br>Click the <b>Gist</b> icon in your toolbar → paste your key → Save.</span>';
        } else {
          bodyEl.innerHTML = `<span class="err">${esc(String(msg.error))}</span>`;
        }
        placeCard();
        try { port.disconnect(); } catch (_) {}
      }
    });

    port.onDisconnect.addListener(() => {
      if (cancelled || finished) return;
      if (started) { lastText = acc; renderResult(acc, false); if (acc.trim()) actionsEl.classList.add("show"); }
      else bodyEl.innerHTML = '<span class="err">Interrupted — try again.</span>';
    });

    port.postMessage({ type: "gist", mode: currentMode, text: selectedText, question: currentQuestion });
  }

  function openCard() {
    trigger.style.display = "none";
    cardMoved = false; // fresh open anchors to the selection again
    if (!alive()) { showRefresh(); return; }
    let p;
    try { p = chrome.storage.local.get(["defaultMode"]); }
    catch (_) { showRefresh(); return; }
    p.then(({ defaultMode }) => {
      currentMode = MODES.includes(defaultMode) ? defaultMode : "summarize";
      currentQuestion = null;
      run();
    }).catch(() => { currentMode = "summarize"; currentQuestion = null; run(); });
  }

  function hideAll() {
    if (currentRun) { currentRun.cancel(); currentRun = null; }
    trigger.style.display = "none";
    card.style.display = "none";
  }

  const insideUs = (e) => e.composedPath && e.composedPath().includes(host);

  trigger.addEventListener("mousedown", (e) => { e.preventDefault(); e.stopPropagation(); });
  trigger.addEventListener("click", (e) => { e.preventDefault(); e.stopPropagation(); openCard(); });
  card.querySelector("[data-x]").addEventListener("click", hideAll);

  // Drag the card by its header (anywhere except the × close button).
  card.querySelector(".head").addEventListener("mousedown", (e) => {
    if (e.target.closest("[data-x]")) return;
    dragging = true;
    const r = card.getBoundingClientRect();
    dragDX = e.clientX - r.left;
    dragDY = e.clientY - r.top;
    e.preventDefault(); // don't start a page text-selection while dragging
  });

  tabsEl.addEventListener("click", (e) => {
    const t = e.target.closest(".tab");
    if (!t) return;
    currentMode = t.dataset.mode;
    currentQuestion = null;
    try { chrome.storage.local.set({ defaultMode: currentMode }); } catch (_) {} // remember (ignore if orphaned)
    run();
  });

  copyBtn.addEventListener("click", () => {
    if (!lastText) return;
    copyText(lastText).then((ok) => {
      copyBtn.textContent = ok ? "✓ Copied" : "Copy failed";
      clearTimeout(copyTimer);
      copyTimer = setTimeout(() => { copyBtn.textContent = "⧉ Copy"; }, 1400);
    });
  });

  card.querySelector("[data-regen]").addEventListener("click", () => run());

  function submitAsk() {
    const q = askInput.value.trim();
    if (!q) return;
    currentMode = "ask";
    currentQuestion = q;
    askInput.value = "";
    run();
  }
  card.querySelector("[data-ask]").addEventListener("click", submitAsk);
  askInput.addEventListener("keydown", (e) => { if (e.key === "Enter") { e.preventDefault(); submitAsk(); } });

  // Clicking anywhere outside our UI dismisses it (and cancels any live stream).
  document.addEventListener("mousedown", (e) => { if (!insideUs(e)) hideAll(); }, true);
  // Esc closes the card.
  document.addEventListener("keydown", (e) => { if (e.key === "Escape" && card.style.display === "block") hideAll(); });

  // Drag move / release (capture, so pages that stopPropagation can't break it).
  document.addEventListener("mousemove", (e) => {
    if (!dragging) return;
    const w = card.offsetWidth, h = card.offsetHeight;
    const x = Math.min(Math.max(8, e.clientX - dragDX), window.innerWidth - w - 8);
    const y = Math.min(Math.max(8, e.clientY - dragDY), window.innerHeight - h - 8);
    card.style.left = x + "px";
    card.style.top = y + "px";
    cardMoved = true;
    e.preventDefault();
  }, true);
  document.addEventListener("mouseup", () => { dragging = false; }, true);

  // Show the trigger after a selection settles.
  document.addEventListener("mouseup", (e) => {
    if (insideUs(e)) return;
    setTimeout(() => {
      if (!captureSelection()) return;
      card.style.display = "none";
      trigger.style.display = "flex";
      const tw = trigger.offsetWidth || 84;
      let tx = Math.min(Math.max(8, anchor.right - tw / 2), window.innerWidth - tw - 8);
      let ty = anchor.bottom + 8;
      if (ty > window.innerHeight - 44) ty = Math.max(8, anchor.top - 40);
      trigger.style.left = tx + "px";
      trigger.style.top = ty + "px";
    }, 10);
  });

  // Keyboard shortcut (⌘⇧G by default) → gist the current selection directly, no pill.
  chrome.runtime.onMessage.addListener((msg) => {
    if (!msg || msg.type !== "gist-shortcut") return;
    if (captureSelection()) openCard();
    else showToast("✦ Gist — highlight some text first");
  });
})();
