# Installing Gist on Chrome

A click-by-click guide. No coding, no Chrome Web Store — you load the folder directly.
Takes about 2 minutes. Works the same in **Chrome, Edge, Brave, Arc, and Opera** (any
Chromium browser).

**You'll need:** this `gist-extension` folder, and a free Anthropic API key (Step 6).

---

## Step 1 — Find the folder

Make sure you have the whole **`gist-extension`** folder on your computer. It should
contain `manifest.json` plus `background.js`, `content.js`, `popup.html`, and an `icons`
folder. (On this machine it lives at `AI_BlogSite/Apps/gist-extension/`.)

> Keep the folder somewhere permanent — if you move or delete it later, the extension
> stops working. Chrome loads it from wherever it sits.

## Step 2 — Open the Extensions page

In Chrome, click the address bar, type **`chrome://extensions`**, and press Enter.
(Or: **⋮ menu → Extensions → Manage Extensions**.)

## Step 3 — Turn on Developer mode

Flip the **Developer mode** switch in the **top-right** corner to **on**. Three buttons
appear on the left: *Load unpacked*, *Pack extension*, *Update*.

## Step 4 — Load the extension

1. Click **Load unpacked** (top-left).
2. In the file picker, navigate to and select the **`gist-extension`** folder itself
   (the one that contains `manifest.json`) and confirm.

A **✦ Gist** card appears in your list. That's it — it's installed.

> **Important:** select the `gist-extension` folder, *not* a parent folder and *not* a
> single file. Chrome needs the folder that has `manifest.json` directly inside it.

## Step 5 — Pin it to the toolbar (recommended)

Click the **puzzle-piece icon** (Extensions) near the top-right of Chrome, find **Gist**,
and click the **pin** icon. The red **✦** now sits in your toolbar for quick access to
settings.

## Step 6 — Add your Anthropic API key (one time)

Gist runs on **your own** Claude API key — it's never built in, and it's only ever sent
to Anthropic.

1. Get a key at **[console.anthropic.com/settings/keys](https://console.anthropic.com/settings/keys)**
   (sign in → *Create Key* → copy it; it starts with `sk-ant-`).
2. Click the **✦ Gist** toolbar icon.
3. Paste the key, pick a **model** (Haiku 4.5 is the fast, cheap default), leave the
   default mode on *Summarize*, and click **Save**.

## Step 7 — Try it

Go to any normal web page (a news article, a blog, a docs page) and either:

- **Highlight** some text → click the little **✦ Gist** pill that pops up, **or**
- Highlight text and press **⌘⇧G** (Mac) / **Ctrl+Shift+G** (Windows/Linux).

A card streams in with the **TL;DR**. Switch **Summarize / Explain / Rewrite** with the
tabs, **⧉ Copy** the result, **↻ Retry**, or type a **follow-up question** at the bottom.
Press **Esc** or click away to close.

---

## Updating to a new version

When the files change (e.g. a new version number), just open **`chrome://extensions`** and
click the **↻ reload** icon on the Gist card. Your API key and settings are kept.

## Troubleshooting

| Symptom | Fix |
|---|---|
| **No ✦ pill when I highlight** | Reload the web page once after installing — the script only runs on pages opened/refreshed *after* install. It also doesn't run on `chrome://` pages, the New Tab page, or the Chrome Web Store. |
| **"Add your Anthropic API key"** | You haven't saved a key yet — do Step 6. |
| **"Invalid API key (401)"** | The key is wrong, expired, or has a typo. Re-copy it from the Anthropic console and Save again. |
| **"Rate limited (429)"** | Too many requests — wait a few seconds and retry. |
| **The shortcut does nothing** | The ⌘⇧G / Ctrl+Shift+G combo may already be taken. Set your own at **`chrome://extensions/shortcuts`** (the popup's **Change** button opens it). Also make sure you're on a normal web page. |
| **"Service worker registration failed" / won't load** | You probably selected the wrong folder in Step 4 — pick the one with `manifest.json` directly inside. |
| **It stopped working after I moved files** | Chrome loads the extension from its original location. Put the folder back, or remove and re-load it from the new spot. |

## Privacy & cost

- Your API key is stored **locally** in your browser (`chrome.storage.local`) and is sent
  **only** to `api.anthropic.com`. Never paste an API key into a random website — only
  into this extension's popup.
- When you run a gist, the **text you selected** is sent to Anthropic to generate the
  response. Nothing is sent to us or to the page you're on.
- Each gist is **one Claude API call** billed to your key. Haiku 4.5 keeps it very cheap;
  switch models in the popup if you want deeper output.

## Uninstalling

Open **`chrome://extensions`**, find **Gist**, and click **Remove**. That's it.

---

Built with Claude, zero code — part of *The Stack* by
[AIToolsDaily24](https://aitoolsdaily24.com).
