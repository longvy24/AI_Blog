// Gist popup — loads current settings and saves the user's own API key + prefs to
// chrome.storage.local. Nothing here is transmitted anywhere except by the background
// worker to api.anthropic.com when you actually run Gist.

const $ = (id) => document.getElementById(id);

chrome.storage.local.get(["apiKey", "model", "defaultMode"]).then(({ apiKey, model, defaultMode }) => {
  if (apiKey) $("key").value = apiKey;
  if (model) $("model").value = model;
  $("mode").value = defaultMode || "summarize";
});

$("reveal").addEventListener("click", () => {
  const k = $("key");
  const show = k.type === "password";
  k.type = show ? "text" : "password";
  $("reveal").textContent = show ? "Hide" : "Show";
});

$("save").addEventListener("click", () => {
  const apiKey = $("key").value.trim();
  chrome.storage.local
    .set({ apiKey, model: $("model").value, defaultMode: $("mode").value })
    .then(() => {
      $("status").textContent = apiKey
        ? "✓ Saved — highlight some text to try it."
        : "Saved (no key yet — paste one to enable Gist).";
      setTimeout(() => { $("status").textContent = ""; }, 2800);
    });
});

$("key").addEventListener("keydown", (e) => { if (e.key === "Enter") $("save").click(); });

// Show the actual bound shortcut (may differ from the default if the user rebound it
// or if Chrome couldn't claim the suggested key), and offer a one-click rebind.
if (chrome.commands && chrome.commands.getAll) {
  chrome.commands.getAll().then((cmds) => {
    const c = (cmds || []).find((x) => x.name === "gist-selection");
    $("shortcut").value = c && c.shortcut ? c.shortcut : "Not set — click Change";
  });
}
$("changeSc").addEventListener("click", () => {
  chrome.tabs.create({ url: "chrome://extensions/shortcuts" });
});
