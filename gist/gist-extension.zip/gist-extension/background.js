// Gist — background service worker.
// Owns the network call to Claude so the content script never touches page CORS.
// Streams the response over a long-lived port: one "chunk" message per text delta,
// then "done" (or "error"). If the content script disconnects (card closed / new
// request), the in-flight fetch is aborted so you don't pay for tokens you won't see.
//
// The API key lives in chrome.storage.local (set by the user in the popup) and is
// sent only to api.anthropic.com. It is never hardcoded here.

const API_URL = "https://api.anthropic.com/v1/messages";
const DEFAULT_MODEL = "claude-haiku-4-5-20251001";

// Every mode answers in TL;DR style: one punchy line starting exactly with "TL;DR:",
// then a few tight bullets ("- "). No intros, no wind-up, no filler. The card renders
// the TL;DR line and bullets for a scannable result.
const TLDR_STYLE =
  "Always answer in TL;DR style. Line 1 must start exactly with 'TL;DR:' and deliver the single most important point in the fewest words possible. Then add 2 to 4 short bullet points, each on its own line starting with '- '. No preamble, no conclusion, no filler — every word earns its place.";

const SYSTEM_PROMPTS = {
  summarize:
    "You are Gist, a reading assistant. Summarize the user's text faithfully and neutrally; never invent anything that isn't in it. " + TLDR_STYLE,
  explain:
    "You are Gist, a reading assistant. Explain the user's text in plain, simple language a non-expert would get; define any jargon in the bullets. Don't add outside facts beyond what's needed to clarify. " + TLDR_STYLE,
  rewrite:
    "You are Gist, a reading assistant. Rewrite the user's text to be clearer and tighter while preserving its meaning and tone — cut everything non-essential. " + TLDR_STYLE +
    " Here, the 'TL;DR:' line is the core message rewritten crisply, and the bullets are the remaining points rewritten (skip the bullets if the text is a single point).",
  ask:
    "You are Gist, a reading assistant. The user selected some text and asked a question about it. Answer grounded in that text, using general knowledge only to clarify; if the text doesn't contain the answer, say so in the TL;DR line. " + TLDR_STYLE
};

async function streamClaude(port, send, { mode, text, question }) {
  const { apiKey, model } = await chrome.storage.local.get(["apiKey", "model"]);
  if (!apiKey) { send({ type: "error", error: "NO_KEY" }); return; }

  const system = SYSTEM_PROMPTS[mode] || SYSTEM_PROMPTS.summarize;
  const userContent =
    mode === "ask" && question
      ? `Here is some text:\n"""\n${text}\n"""\n\nQuestion: ${question}`
      : text;
  const controller = new AbortController();
  port.onDisconnect.addListener(() => controller.abort());

  let res;
  try {
    res = await fetch(API_URL, {
      method: "POST",
      signal: controller.signal,
      headers: {
        "content-type": "application/json",
        "x-api-key": apiKey,
        "anthropic-version": "2023-06-01",
        // Required to call the API directly from a browser/extension origin.
        "anthropic-dangerous-direct-browser-access": "true"
      },
      body: JSON.stringify({
        model: model || DEFAULT_MODEL,
        max_tokens: 1024,
        stream: true,
        system,
        messages: [{ role: "user", content: userContent }]
      })
    });
  } catch (e) {
    if (!controller.signal.aborted) send({ type: "error", error: e?.message || "Network error — is the page online?" });
    return;
  }

  if (!res.ok) {
    let detail = "";
    try { const j = await res.json(); detail = j?.error?.message || ""; } catch (_) {}
    if (res.status === 401) return send({ type: "error", error: "Invalid API key (401). Check it in the Gist popup." });
    if (res.status === 429) return send({ type: "error", error: "Rate limited (429). Wait a moment and retry." });
    return send({ type: "error", error: `HTTP ${res.status}${detail ? " — " + detail : ""}` });
  }

  // Parse the SSE stream: events are newline-delimited; each `data:` line is one
  // complete JSON object whose own `type` tells us what it is.
  const reader = res.body.getReader();
  const decoder = new TextDecoder();
  let buffer = "";
  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      let nl;
      while ((nl = buffer.indexOf("\n")) >= 0) {
        const line = buffer.slice(0, nl).trim();
        buffer = buffer.slice(nl + 1);
        if (!line.startsWith("data:")) continue;
        const payload = line.slice(5).trim();
        if (!payload || payload === "[DONE]") continue;
        let evt;
        try { evt = JSON.parse(payload); } catch (_) { continue; }
        if (evt.type === "content_block_delta" && evt.delta?.type === "text_delta") {
          send({ type: "chunk", text: evt.delta.text });
        } else if (evt.type === "error") {
          send({ type: "error", error: evt.error?.message || "Stream error" });
          return;
        }
      }
    }
    send({ type: "done" });
  } catch (e) {
    if (!controller.signal.aborted) send({ type: "error", error: e?.message || "Stream interrupted" });
  }
}

chrome.runtime.onConnect.addListener((port) => {
  if (port.name !== "gist") return;
  let closed = false;
  port.onDisconnect.addListener(() => { closed = true; });
  // Guarded sender — posting to a disconnected port throws.
  const send = (m) => { if (!closed) { try { port.postMessage(m); } catch (_) {} } };
  port.onMessage.addListener((msg) => {
    if (msg && msg.type === "gist") streamClaude(port, send, msg);
  });
});

// Keyboard shortcut (default ⌘⇧G / Ctrl+Shift+G): ask the active tab's content
// script to gist whatever is selected. Rebindable at chrome://extensions/shortcuts.
// The .catch() swallows "no receiving end" on pages where content scripts can't run
// (chrome:// pages, the Web Store, the New Tab page, etc.).
chrome.commands.onCommand.addListener((command, tab) => {
  if (command !== "gist-selection") return;
  const send = (id) => { if (id != null) chrome.tabs.sendMessage(id, { type: "gist-shortcut" }).catch(() => {}); };
  if (tab && tab.id != null) send(tab.id);
  else chrome.tabs.query({ active: true, currentWindow: true }).then((t) => send(t[0] && t[0].id));
});
